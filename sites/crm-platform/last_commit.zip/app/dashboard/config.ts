export const dynamic = 'force-dynamic';
